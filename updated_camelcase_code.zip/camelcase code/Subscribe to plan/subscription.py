from flask import Flask, request, jsonify
import pandas as pd

app = Flask(__name__)

df = pd.read_excel("D:\\tcc project 1\\DATASET\\SUBSCRIPTION_3.xlsx")

def recommendPlan(watchHours, preferredGenres, simultaneousStreams):
    if watchHours > 150 or simultaneousStreams > 2:
        return "Premium"
    elif watchHours > 60 or simultaneousStreams == 2:
        return "Standard"
    else:
        return "Basic"

@app.route('/recommendPlan', methods=['POST'])
def getRecommendation():
    data = request.json
    watchHours = data.get('watchHours', 0)
    preferredGenres = data.get('preferredGenres', [])
    simultaneousStreams = data.get('simultaneousStreams', 1)
    
    recommended = recommendPlan(watchHours, preferredGenres, simultaneousStreams)
    planDetails = df[df["Plan"] == recommended].to_dict(orient='records')[0]
    
    return jsonify({
        "recommendedPlan": recommended,
        "details": planDetails
    })

if __name__ == '__main__':
    app.run(debug=True)
