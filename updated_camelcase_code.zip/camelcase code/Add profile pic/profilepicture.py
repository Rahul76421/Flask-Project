from flask import Flask, request, jsonify
import pandas as pd
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import LabelEncoder

app = Flask(__name__)

# Load dataset dynamically
datasetPath = "D:\\tcc project 1\\DATASET\\PROFILE_PIC_5.xlsx"
data = pd.read_excel(datasetPath)

# Encode 'interests'
labelEncoder = LabelEncoder()
data['interestsEncoded'] = labelEncoder.fit_transform(data['interests'])

# AI Model - Nearest Neighbors
features = data[['profilePicAdded', 'interestsEncoded', 'engagementScore']]
model = NearestNeighbors(n_neighbors=3, metric='euclidean')
model.fit(features)

@app.route('/recommendProfileCompletion', methods=['POST'])
def recommendProfileCompletion():
    requestData = request.get_json()
    profilePicAdded = requestData.get('profilePicAdded', 0)
    engagementScore = requestData.get('engagementScore', 0)

    if profilePicAdded == 1:
        return jsonify({"message": "✅ Your profile looks great with a picture already!"})

    # AI - Suggest if no profile pic
    distances, indices = model.kneighbors([[0, 0, engagementScore]])

    similarUsers = []
    for idx in indices[0]:
        user = data.iloc[idx]
        similarUsers.append({
            "userId": int(user['userId']),
            "interests": user['interests'],
            "engagementScore": int(user['engagementScore'])
        })

    return jsonify({
        "message": "⚠️ We noticed your profile doesn't have a picture.\n👉 Add a profile picture to build trust and improve your profile visibility!\n💡 Personalized content and more connections await once your profile is complete!",
        "similarUsersEngagement": similarUsers
    })

if __name__ == '__main__':
    app.run(debug=True)
