from flask import Flask, request, jsonify
import pandas as pd

app = Flask(__name__)

df = pd.read_excel("D:\\tcc project 1\\DATASET\\USER_REVIEW_2.xlsx")

C = df["AverageRating"].mean()
m = 100

def weightedRating(row, m=m, C=C):
    v = row["ReviewCount"]
    R = row["AverageRating"]
    return (v / (v + m)) * R + (m / (v + m)) * C

df["WeightedRating"] = df.apply(weightedRating, axis=1)

@app.route('/api/video-recommendations', methods=['GET'])
def recommend():
    topN = request.args.get('topN', default=5, type=int)
    topVideos = df.sort_values(by="WeightedRating", ascending=False).head(topN)
    recommendations = topVideos[["VideoTitle", "ReviewCount", "AverageRating", "WeightedRating"]].to_dict(orient="records")
    return jsonify({"success": True, "recommendations": recommendations})

if __name__ == '__main__':
    app.run(debug=True, port=5000)