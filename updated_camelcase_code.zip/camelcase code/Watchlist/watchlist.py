from flask import Flask, request, jsonify
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

contentData = pd.read_excel("D:\\tcc project 1\\DATASET\\WATCHLIST_1.xlsx")

vectorizer = TfidfVectorizer(stop_words='english')
tfidfMatrix = vectorizer.fit_transform(contentData['description'])

@app.route('/recommend', methods=['POST'])
def recommend():
    data = request.get_json()
    watchlistIds = data.get('watchlist', [])

    if not watchlistIds:
        return jsonify({"error": "Watchlist cannot be empty"}), 400

    watchlistIndices = contentData[contentData['id'].isin(watchlistIds)].index.tolist()
    if not watchlistIndices:
        return jsonify({"error": "No valid movies found in watchlist"}), 404

    watchlistTfidf = tfidfMatrix[watchlistIndices]
    similarityScores = cosine_similarity(watchlistTfidf, tfidfMatrix)
    meanScores = similarityScores.mean(axis=0)

    for idx in watchlistIndices:
        meanScores[idx] = -1

    recommendedIndices = meanScores.argsort()[-3:][::-1]
    recommendations = contentData.iloc[recommendedIndices][['id', 'title']].to_dict(orient='records')

    return jsonify({"recommendations": recommendations})

if __name__ == '__main__':
    app.run(debug=True)
