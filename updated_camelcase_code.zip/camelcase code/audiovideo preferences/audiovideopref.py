from flask import Flask, request, jsonify
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

datasetPath = r"D:\tcc project 1\DATASET\audio_video_dataset_with_userId.xlsx"

dataFrame = pd.read_excel(datasetPath)
dataFrame.columns = dataFrame.columns.str.strip()

dataFrame['combinedFeatures'] = dataFrame['audioQuality'] + " " + dataFrame['videoQuality'] + " " + dataFrame['captionEnabled']

vectorizer = TfidfVectorizer()
tfidfMatrix = vectorizer.fit_transform(dataFrame['combinedFeatures'])

@app.route('/recommendAudioVideo', methods=['GET'])
def recommendAudioVideo():
    audioQuality = request.args.get('audioQuality', default='dolby')
    videoQuality = request.args.get('videoQuality', default='4k')
    captionEnabled = request.args.get('captionEnabled', default='true')

    userInput = audioQuality + " " + videoQuality + " " + captionEnabled
    userVector = vectorizer.transform([userInput])

    cosineSim = cosine_similarity(userVector, tfidfMatrix).flatten()

    topIndices = cosineSim.argsort()[-5:][::-1]

    recommendations = []
    for idx in topIndices:
        recommendations.append({
            'id': int(dataFrame.iloc[idx]['id']),
            'userId': dataFrame.iloc[idx]['userId'],
            'title': dataFrame.iloc[idx]['title'],
            'audioQuality': dataFrame.iloc[idx]['audioQuality'],
            'videoQuality': dataFrame.iloc[idx]['videoQuality'],
            'captionEnabled': dataFrame.iloc[idx]['captionEnabled']
        })

    return jsonify({'recommendations': recommendations})

if __name__ == '__main__':
    app.run(debug=True)
