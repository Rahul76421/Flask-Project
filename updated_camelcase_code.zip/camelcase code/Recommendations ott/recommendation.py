from flask import Flask, request, jsonify
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

df = pd.read_excel("D:\\tcc project 1\\DATASET\\RECOMMENDATION_4.xlsx")

interactionMatrix = df.pivot_table(index='userID', columns='videoTitle', aggfunc='size', fill_value=0)
cosineSim = cosine_similarity(interactionMatrix.T)

def getSimilarVideos(videoTitle, topN=5):
    videoIdx = interactionMatrix.columns.get_loc(videoTitle)
    similarityScores = list(enumerate(cosineSim[videoIdx]))
    sortedVideos = sorted(similarityScores, key=lambda x: x[1], reverse=True)
    topVideos = [interactionMatrix.columns[i[0]] for i in sortedVideos[1:topN+1]]
    return topVideos

@app.route('/api/videoRecommendations', methods=['GET'])
def recommend():
    userID = request.args.get('userID', type=int)
    if not userID:
        return jsonify({"error": "User ID is required."}), 400

    watchedVideos = df[df['userID'] == userID]['videoTitle'].tolist()
    recommendations = []
    for video in watchedVideos:
        similarVideos = getSimilarVideos(video)
        recommendations.extend(similarVideos)

    recommendations = list(set(recommendations))[:5]
    return jsonify({
        "success": True,
        "userID": userID,
        "recommendedVideos": recommendations
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)