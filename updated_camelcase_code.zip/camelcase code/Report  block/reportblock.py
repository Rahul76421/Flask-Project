from flask import Flask, request, jsonify
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

datasetPath = r"D:\tcc project 1\DATASET\report_block_dataset_final.xlsx"
data = pd.read_excel(datasetPath)

data.columns = data.columns.str.strip()

data['combinedText'] = data['contentTitle'] + " " + data['contentType'] + " " + data['flaggedReason'].fillna('')

vectorizer = TfidfVectorizer()
tfidfMatrix = vectorizer.fit_transform(data['combinedText'])

@app.route('/reportBlockRecommend', methods=['POST'])
def reportBlockRecommend():
    userData = request.get_json()
    viewedContentIds = userData.get('viewedContentIds', [])

    viewedData = data[data['contentId'].isin(viewedContentIds)]

    if viewedData.empty:
        return jsonify({
            "message": "✅ No viewed content found.",
            "recommendations": []
        })

    flaggedData = viewedData[viewedData['flaggedReason'].notnull() & (viewedData['flaggedReason'] != "-")]

    if flaggedData.empty:
        return jsonify({
            "message": "✅ No harmful or flagged content detected in your viewed content.",
            "recommendations": []
        })

    userInputText = " ".join(flaggedData['combinedText'].tolist())
    userVec = vectorizer.transform([userInputText])
    similarityScores = cosine_similarity(userVec, tfidfMatrix)

    topIndices = similarityScores[0].argsort()[-5:][::-1]

    recommendations = []
    for idx in topIndices:
        row = data.iloc[idx]
        if row['flaggedReason'] != "-" and row['contentId'] in viewedContentIds:
            recommendations.append({
                "contentId": int(row['contentId']),
                "contentTitle": row['contentTitle'],
                "contentType": row['contentType'],
                "flaggedReason": row['flaggedReason'],
                "recommendation": "⚠️ Recommended to report or block this content."
            })

    return jsonify({
        "message": "⚠️ Harmful content detected. Below are the recommendations:",
        "recommendations": recommendations
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
