from flask import Flask, request, jsonify
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

# Dataset path
datasetPath = r"D:\tcc project 1\DATASET\BIO_9.xlsx"

# Load dataset
df = pd.read_excel(datasetPath)

# Extract category and description columns
trainingData = df["DESCRIPTION"].dropna().tolist()
categoryData = df["CATEGORY"].dropna().tolist()

# Prepare suggestions dynamically
suggestions = {
    category.lower(): [
        f"Highlight your experience or expertise in {category.lower()}",
        f"Example: '{category} Enthusiast | Passionate about {category.lower()}'"
    ]
    for category in categoryData
}

@app.route('/aiBioSuggest', methods=['POST'])
def aiBioSuggest():
    data = request.get_json()
    userInput = data.get('input', '')

    if not userInput:
        return jsonify({"error": "Input is required"}), 400

    # Vectorize training data and user input
    vectorizer = TfidfVectorizer()
    tfidfMatrix = vectorizer.fit_transform(trainingData + [userInput])

    # Calculate cosine similarity
    similarityScores = cosine_similarity(tfidfMatrix[-1], tfidfMatrix[:-1]).flatten()

    # Find best matching profile type
    bestMatchIndex = np.argmax(similarityScores)
    matchedProfile = categoryData[bestMatchIndex].lower()

    # Fetch relevant suggestions
    if matchedProfile in suggestions:
        return jsonify({
            "status": "success",
            "matchedProfile": matchedProfile,
            "personalizedSuggestions": suggestions[matchedProfile]
        })

    # General fallback suggestions
    return jsonify({
        "status": "general",
        "personalizedSuggestions": [
            "Mention your hobbies or profession.",
            "Example: 'Traveler | Foodie | Tech Geek'"
        ]
    })

if __name__ == '__main__':
    app.run(debug=True)
