from flask import Flask, request, jsonify
import numpy as np
import pandas as pd
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, Input

app = Flask(__name__)

filePath = r"D:\tcc project 1\DATASET\engagement_data_with_post_id.xlsx"

def createModel():
    model = Sequential()
    model.add(Input(shape=(1, 3)))
    model.add(LSTM(50, activation='relu'))
    model.add(Dropout(0.2))
    model.add(Dense(3))
    model.compile(optimizer='adam', loss='mse')
    return model

model = createModel()
sampleData = np.random.randint(1000, 5000, (30, 3))
xTrain = sampleData.reshape((30, 1, 3))
model.fit(xTrain, xTrain, epochs=200, verbose=0)

@app.route('/predictEngagement', methods=['POST'])
def predictEngagement():
    try:
        requestData = request.get_json()
        postId = requestData.get('post_id', None)

        dataFrame = pd.read_excel(filePath)

        if postId is None or postId >= len(dataFrame):
            return jsonify({"status": "error", "message": "Invalid or missing post_id"})

        post = dataFrame.iloc[postId]
        views = post['views']
        likes = post['likes']
        comments = post['comments']

        inputData = np.array([[views, likes, comments]]).reshape((1, 1, 3))
        prediction = model.predict(inputData)

        recommendation = "✅ Great Post! Keep it up!" if prediction[0][1] > 500 else "⚠️ Needs improvement!"

        return jsonify({
            "status": "success",
            "inputPost": {
                "views": int(views),
                "likes": int(likes),
                "comments": int(comments)
            },
            "predictedViews": int(prediction[0][0]),
            "predictedLikes": int(prediction[0][1]),
            "predictedComments": int(prediction[0][2]),
            "recommendation": recommendation
        })

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

if __name__ == '__main__':
    app.run(debug=True)
