from flask import Flask, request, jsonify
import pandas as pd
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import LabelEncoder

app = Flask(__name__)

datasetPath = r"D:\tcc project 1\DATASET\account_privacy_dataset.xlsx"
data = pd.read_excel(datasetPath)

data.columns = data.columns.str.strip()

lePrivate = LabelEncoder()
data['prefersPrivateEncoded'] = lePrivate.fit_transform(data['prefersPrivate'])

featureColumns = ['postsPublic', 'followers', 'engagementScore', 'prefersPrivateEncoded']
model = NearestNeighbors(n_neighbors=5, metric='euclidean')
model.fit(data[featureColumns])

@app.route('/recommendPrivacy', methods=['POST'])
def recommendPrivacy():
    userData = request.get_json()
    postsPublic = userData.get('postsPublic', 50)
    followers = userData.get('followers', 500)
    engagementScore = userData.get('engagementScore', 50)
    prefersPrivate = userData.get('prefersPrivate', 'No')

    if prefersPrivate not in lePrivate.classes_:
        return jsonify({"error": "Invalid 'prefersPrivate' value. Use 'Yes' or 'No'."}), 400

    prefersPrivateEncoded = lePrivate.transform([prefersPrivate])[0]

    distances, indices = model.kneighbors([[postsPublic, followers, engagementScore, prefersPrivateEncoded]])

    similarPrivacySettings = data.iloc[indices[0]]['currentPrivacy'].value_counts()
    recommendedPrivacy = similarPrivacySettings.idxmax()

    if recommendedPrivacy == 'Private':
        reason = "High engagement score and followers indicate privacy risks. 'Private' is safer."
    elif recommendedPrivacy == 'Public':
        reason = "Your profile looks optimized for wider audience reach. 'Public' is suitable."
    else:
        reason = "Balanced profile detected. 'Friends Only' keeps your content visible to known people."

    return jsonify({
        "status": "success",
        "message": f"Based on your profile activity and preferences, we recommend setting your account privacy to '{recommendedPrivacy}' for better control.",
        "recommendedPrivacy": recommendedPrivacy,
        "details": {
            "reason": reason
        }
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
