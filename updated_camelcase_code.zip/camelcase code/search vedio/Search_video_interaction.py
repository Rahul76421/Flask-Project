from flask import Flask, request, jsonify
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

# Load Excel data
dataFilePath = r"D:\tcc project 1\DATASET\search recc.xlsx"
dataFrame = pd.read_excel(dataFilePath)

# Ensure expected columns are present
requiredColumns = ['contentTitle', 'category']
for col in requiredColumns:
    if col not in dataFrame.columns:
        raise ValueError(f"Missing required column: {col}")

# Combine contentTitle and category for better matching
dataFrame['combinedText'] = dataFrame['contentTitle'].astype(str) + " " + dataFrame['category'].astype(str)

# Prepare TF-IDF vectorizer
tfidfVectorizer = TfidfVectorizer(stop_words='english')
tfidfMatrix = tfidfVectorizer.fit_transform(dataFrame['combinedText'])

@app.route('/searchRecommend', methods=['POST'])
def searchRecommend():
    requestData = request.get_json()
    searchQuery = requestData.get('searchQuery', '').strip()

    if not searchQuery:
        return jsonify({"status": "error", "message": "searchQuery is required!"}), 400

    # Vectorize the search query
    queryVector = tfidfVectorizer.transform([searchQuery])
    similarityScores = cosine_similarity(queryVector, tfidfMatrix).flatten()

    # Get top 5 similar results
    topIndices = similarityScores.argsort()[::-1][:5]
    recommendations = []

    for index in topIndices:
        recommendations.append({
            "contentTitle": dataFrame.iloc[index]['contentTitle'],
            "category": dataFrame.iloc[index]['category']
        })

    return jsonify({
        "status": "success",
        "recommendations": recommendations
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
