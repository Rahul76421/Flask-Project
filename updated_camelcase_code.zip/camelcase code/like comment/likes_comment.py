from flask import Flask, request, jsonify
import pandas as pd
import numpy as np
from sklearn.decomposition import TruncatedSVD
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

# Load dataset
dataset_path = r"D:\tcc project 1\DATASET\LIKE_COMMENT_7.xlsx"
df = pd.read_excel(dataset_path)

# Create user-item matrix
userItemMatrix = df.pivot_table(index='userId', columns='videoId', values='likeStatus', fill_value=0)

# Perform matrix factorization (SVD)
svd = TruncatedSVD(n_components=2)
svdMatrix = svd.fit_transform(userItemMatrix)

# Calculate cosine similarity
cosineSim = cosine_similarity(svdMatrix)

# Recommend videos based on cosine similarity
def recommendVideos(videoId, numRecommendations=3):
    if videoId not in userItemMatrix.columns:
        return []
    
    videoIdx = userItemMatrix.columns.get_loc(videoId)
    similarIndices = cosineSim[videoIdx].argsort()[-numRecommendations-1:-1][::-1]
    recommendations = [int(userItemMatrix.columns[i]) for i in similarIndices]
    return recommendations

@app.route('/recommend', methods=['POST'])
def getRecommendations():
    data = request.get_json()
    userId = data.get('userId')
    videoId = data.get('videoId')

    if userId is None or videoId is None:
        return jsonify({'error': 'userId and videoId are required'}), 400

    recommendations = recommendVideos(videoId)

    return jsonify({'recommendedVideos': recommendations})

if __name__ == '__main__':
    app.run(debug=True)
