from flask import Flask, request, jsonify
import pandas as pd
import random

app = Flask(__name__)

# Load dataset dynamically
datasetPath = "D:\\tcc project 1\\DATASET\\PLAY_VIDEO_6.xlsx"
videoData = pd.read_excel(datasetPath)

# Convert dataset to a list of dictionaries
videoDb = videoData.to_dict(orient="records")

def suggestRelatedVideos(currentVideoId, preferredGenres):
    # Find the genre of the current video
    currentVideo = next((v for v in videoDb if v['videoId'] == currentVideoId), None)
    if not currentVideo:
        return []

    currentGenre = currentVideo['genre']
    
    # Suggest videos from the same genre or preferred genres, excluding the current video
    suggestions = [
        v for v in videoDb
        if v['videoId'] != currentVideoId and (v['genre'] == currentGenre or v['genre'] in preferredGenres)
    ]

    # If no strong match, pick random
    if not suggestions:
        suggestions = random.sample(videoDb, min(3, len(videoDb)))

    # Limit suggestions to 3
    return random.sample(suggestions, min(3, len(suggestions)))

@app.route('/suggestVideos', methods=['POST'])
def suggestVideos():
    requestData = request.json
    videoId = requestData.get('videoId')
    preferredGenres = requestData.get('preferredGenres', [])

    suggested = suggestRelatedVideos(videoId, preferredGenres)

    return jsonify({
        "suggestions": suggested
    })

if __name__ == '__main__':
    app.run(debug=True)
