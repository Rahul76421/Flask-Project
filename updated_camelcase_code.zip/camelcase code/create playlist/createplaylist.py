from flask import Flask, request, jsonify
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

datasetPath = r"D:\tcc project 1\DATASET\ex_updated_camelcase_with_userId.xlsx"
dataFrame = pd.read_excel(datasetPath)
dataFrame.drop_duplicates(subset='songName', inplace=True)
dataFrame.fillna('', inplace=True)

dataFrame['userRating'] = dataFrame['userRating'].astype(str).str.extract(r'(\d+\.?\d*)').astype(float)

dataFrame['combinedFeatures'] = (
    dataFrame['genre'] + ' ' +
    dataFrame['singerArtists'] + ' ' +
    dataFrame['albumMovie'] + ' ' +
    dataFrame['userRating'].astype(str)
)

vectorizer = TfidfVectorizer(stop_words='english')
featureMatrix = vectorizer.fit_transform(dataFrame['combinedFeatures'])

@app.route('/recommend', methods=['POST'])
def recommend():
    requestData = request.get_json()
    try:
        songName = requestData['songName']
        if songName not in dataFrame['songName'].values:
            return jsonify({"status": "error", "message": "Song not found in database."})

        songIndex = dataFrame.index[dataFrame['songName'] == songName][0]
        cosineSim = cosine_similarity(featureMatrix[songIndex], featureMatrix).flatten()
        similarIndices = cosineSim.argsort()[-6:-1][::-1]

        recommendations = []
        for idx in similarIndices:
            recommendations.append({
                "songName": dataFrame.iloc[idx]['songName'],
                "genre": dataFrame.iloc[idx]['genre'],
                "singerArtists": dataFrame.iloc[idx]['singerArtists'],
                "albumMovie": dataFrame.iloc[idx]['albumMovie'],
                "userRating": float(dataFrame.iloc[idx]['userRating']),
                "userId": str(dataFrame.iloc[idx]['userId'])
            })

        return jsonify({
            "status": "success",
            "inputSong": songName,
            "recommendations": recommendations
        })

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)})

if __name__ == '__main__':
    app.run(debug=True)
