from flask import Flask, request, jsonify
import pandas as pd

app = Flask(__name__)

dataset_path = r"D:\tcc project 1\DATASET\language_content_dataset_2000.xlsx"
dataFrame = pd.read_excel(dataset_path)

@app.route('/searchSuggestions', methods=['GET'])
def search_suggestions():
    language_pref = request.args.get('language', default='').strip()
    search_term = request.args.get('searchTerm', default='').strip()
    DEFAULT_RESULTS = 10  # Fixed to 10 recommendations

    # Filter dataset by language
    filtered_df = dataFrame
    if language_pref:
        filtered_df = filtered_df[filtered_df['language'].str.contains(language_pref, case=False, na=False)]

    # Apply search filter on title
    search_results = pd.DataFrame()
    if search_term:
        search_results = filtered_df[filtered_df['title'].str.contains(search_term, case=False, na=False)]

    suggestions = []

    # Add matching search results first
    for _, row in search_results.iterrows():
        suggestions.append({
            "contentId": int(row['contentId']),
            "language": row['language'],
            "title": row['title']
        })

    # Fill remaining with random same-language content if needed
    if len(suggestions) < DEFAULT_RESULTS:
        needed = DEFAULT_RESULTS - len(suggestions)
        remaining_df = filtered_df[~filtered_df['contentId'].isin([s['contentId'] for s in suggestions])]
        if not remaining_df.empty:
            fill_rows = remaining_df.sample(n=min(needed, len(remaining_df)))
            for _, row in fill_rows.iterrows():
                suggestions.append({
                    "contentId": int(row['contentId']),
                    "language": row['language'],
                    "title": row['title']
                })

    # Ensure exactly 10 results
    suggestions = suggestions[:DEFAULT_RESULTS]

    # Final response
    return jsonify({
        "status": "success",
        "mode": "search" if search_term else "trending",
        "language": language_pref,
        "searchTerm": search_term,
        "suggestions": suggestions
    })

if __name__ == '__main__':
    app.run(debug=True)
