from flask import Flask, request, jsonify
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import pandas as pd

app = Flask(__name__)

# Load CSV data dynamically (use relative path or config)
dataFilePath = r"D:\tcc project 1\DATASET\merged_movie_youtube_data.csv"
dataFrame = pd.read_csv(dataFilePath)

# Dynamically detect movie and genre columns
possibleMovieColumns = ['movie_name', 'MovieName', 'Title', 'title', 'movie', 'name']
possibleGenreColumns = ['genre', 'Genre', 'Genres', 'genres']

movieColumn = next((col for col in possibleMovieColumns if col in dataFrame.columns), None)
genreColumn = next((col for col in possibleGenreColumns if col in dataFrame.columns), None)

if not movieColumn:
    raise ValueError(f"Movie column not found. Available columns: {dataFrame.columns}")

if not genreColumn:
    dataFrame['GenrePlaceholder'] = 'N/A'
    genreColumn = 'GenrePlaceholder'

# Combine movie name and genre for better search matching
movieData = dataFrame[[movieColumn, genreColumn]].dropna(subset=[movieColumn]).astype(str).drop_duplicates()
movieData['SearchText'] = movieData[movieColumn] + " " + movieData[genreColumn]

# TF-IDF Vectorizer on the combined text
vectorizer = TfidfVectorizer()
tfidfMatrix = vectorizer.fit_transform(movieData['SearchText'].tolist())

@app.route('/api/search', methods=['GET'])
def searchMovies():
    query = request.args.get('q', '').strip()

    # If no query, return top 5 movies
    if not query:
        trendingMovies = movieData.head(5).apply(
            lambda row: {"movie": row[movieColumn], "genre": row[genreColumn]}, axis=1
        ).tolist()
        return jsonify({
            "success": True,
            "query": "",
            "suggestions": trendingMovies
        })

    # Vectorize the user query
    queryVector = vectorizer.transform([query])
    similarityScores = cosine_similarity(queryVector, tfidfMatrix).flatten()

    # Get top matches based on similarity
    topIndices = np.argsort(similarityScores)[::-1]
    suggestions = []
    usedMovies = set()

    for index in topIndices:
        if similarityScores[index] > 0:
            row = movieData.iloc[index]
            movieName = row[movieColumn]
            if movieName not in usedMovies:
                suggestions.append({"movie": movieName, "genre": row[genreColumn]})
                usedMovies.add(movieName)
        if len(suggestions) >= 10:
            break

    # If less than 5, fill from random other movies
    if len(suggestions) < 5:
        additionalMovies = movieData[~movieData[movieColumn].isin(usedMovies)].head(5 - len(suggestions))
        for _, row in additionalMovies.iterrows():
            suggestions.append({"movie": row[movieColumn], "genre": row[genreColumn]})
            usedMovies.add(row[movieColumn])

    return jsonify({
        "success": True,
        "query": query,
        "suggestions": suggestions
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
