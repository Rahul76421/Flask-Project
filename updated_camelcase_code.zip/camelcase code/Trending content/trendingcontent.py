from flask import Flask, request, jsonify
import pandas as pd
from sklearn.neighbors import NearestNeighbors
from datetime import datetime

app = Flask(__name__)

# ✅ Dataset path
dataPath = r'C:\Users\pyadn\Downloads\trending_reels_dataset.xlsx'

def loadAndProcessData():
    # Dynamically load dataset
    data = pd.read_excel(dataPath)
    
    # Calculate engagementScore dynamically
    data['engagementScore'] = (
        data['views'] * 0.4 + 
        data['likes'] * 0.3 + 
        data['shares'] * 0.2 + 
        data['comments'] * 0.1
    )
    
    # Convert uploadDate to datetime
    data['uploadDate'] = pd.to_datetime(data['upload_date'], errors='coerce')
    
    # Filter recent uploads (last 15 days)
    recentData = data[data['uploadDate'] >= (datetime.now() - pd.Timedelta(days=15))]
    
    # Fallback to full data if recent is empty
    if recentData.empty:
        recentData = data

    return recentData

@app.route('/getTrendingReels', methods=['GET'])
def getTrendingReels():
    # ✅ Dynamically load and process data
    recentData = loadAndProcessData()

    # ✅ Re-train the model dynamically
    features = recentData[['engagementScore']].values
    model = NearestNeighbors(n_neighbors=min(10, len(recentData)), metric='euclidean')
    model.fit(features)

    # Use the highest engagement score to find similar trending content
    samplePoint = [[recentData['engagementScore'].max()]]
    distances, indices = model.kneighbors(samplePoint)

    recommendations = []
    for idx in indices[0]:
        row = recentData.iloc[idx]
        recommendations.append({
            "contentId": int(row['content_id']),
            "title": row['title'],
            "views": int(row['views']),
            "likes": int(row['likes']),
            "shares": int(row['shares']),
            "comments": int(row['comments']),
            "uploadDate": row['uploadDate'].strftime("%Y-%m-%d") if pd.notnull(row['uploadDate']) else None,
            "engagementScore": float(row['engagementScore'])
        })

    return jsonify({"trendingReels": recommendations})

if __name__ == '__main__':
    app.run(debug=True)
