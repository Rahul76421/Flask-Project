from flask import Flask, request, jsonify
import pandas as pd
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import LabelEncoder

app = Flask(__name__)

data = pd.read_excel(r"D:\tcc project 1\DATASET\search_user_realistic_dataset_unique.xlsx")

le = LabelEncoder()
data['interestEncoded'] = le.fit_transform(data['interest'])

featureColumns = ['interestEncoded', 'mutualConnections', 'followers', 'postsCount']
model = NearestNeighbors(n_neighbors=10, metric='euclidean')
model.fit(data[featureColumns])

@app.route('/recommendUsers', methods=['POST'])
def recommend_users():
    userData = request.get_json()
    userInterest = userData.get('interest')
    mutualConnections = userData.get('mutualConnections', 10)
    followers = userData.get('followers', 100)
    postsCount = userData.get('postsCount', 50)

    if userInterest not in le.classes_:
        return jsonify({"error": "Interest not found in dataset."}), 404

    interestEncoded = le.transform([userInterest])[0]

    distances, indices = model.kneighbors([[interestEncoded, mutualConnections, followers, postsCount]])

    recommendedUsers = []
    for idx in indices[0]:
        userRow = data.iloc[idx]
        userDict = {}
        for col in data.columns:
            camelCaseCol = ''.join([word.capitalize() if i != 0 else word for i, word in enumerate(col.split('_'))])
            userDict[camelCaseCol] = int(userRow[col]) if pd.api.types.is_integer_dtype(data[col]) else str(userRow[col])
        recommendedUsers.append(userDict)

    return jsonify({"recommendedUsers": recommendedUsers})

if __name__ == '__main__':
    app.run(debug=True)
