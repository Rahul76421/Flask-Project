from flask import Flask, request, jsonify
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import pandas as pd

app = Flask(__name__)

# Dataset path
dataset_path = r"D:\tcc project 1\DATASET\LIVE_STREAM_8(3).xlsx"

# Load dataset
df = pd.read_excel(dataset_path)

# Separate user and stream data
userData = df[['userId', 'interests']].drop_duplicates()
streamData = df[['streamId', 'title', 'creator', 'genre']].drop_duplicates()

vectorizer = TfidfVectorizer()

@app.route('/recommendlive', methods=['GET'])
def recommend_streams():
    user_id = request.args.get('userId', type=int)

    if user_id is None:
        return jsonify({"error": "userId is required"}), 400

    user = userData[userData['userId'] == user_id]
    if user.empty:
        return jsonify({"error": "User not found"}), 404

    user_interest_text = user['interests'].values[0]
    if pd.isna(user_interest_text) or user_interest_text.strip() == "":
        return jsonify({"error": "User interests are empty"}), 400

    stream_genres = streamData['genre'].dropna().tolist()  # Drop NaN values
    if not stream_genres:
        return jsonify({"error": "No stream genres available for comparison"}), 400

    combined = [user_interest_text] + stream_genres
    tfidf_matrix = vectorizer.fit_transform(combined)
    cosine_sim = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:]).flatten()

    top_n = min(3, len(cosine_sim))
    top_indices = cosine_sim.argsort()[-top_n:][::-1]

    recommendations = streamData.iloc[top_indices]

    recommended_streams = [
        {
            "streamId": row.streamId,
            "title": row.title,
            "creator": row.creator,
            "genre": row.genre,
            "similarityScore": round(float(cosine_sim[idx]), 2)
        }
        for idx, row in zip(top_indices, recommendations.itertuples(index=False))
    ]

    return jsonify({
        "userId": user_id,
        "userInterest": user_interest_text,
        "recommendedStreams": recommended_streams
    })

if __name__ == '__main__':
    app.run(debug=True)
